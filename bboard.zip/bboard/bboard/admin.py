from django.contrib import admin

from bboard.models import Rubric, Bb

admin.site.register(Rubric)
admin.site.register(Bb)
