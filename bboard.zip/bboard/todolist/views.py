from django.shortcuts import render

def todo_list(request):
    pass

def todo_detail(request, todo_id):
    pass


def todo_create(request):
    pass

def todo_update(request, todo_id):
    pass


def todo_delete(request, todo_id):
    pass
